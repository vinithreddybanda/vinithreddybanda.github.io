import * as THREE from "three";

const canvas = document.querySelector("#storybook-world");
const stage = document.querySelector("[data-world-stage]");
const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;

if (canvas && stage) {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 60);
  camera.position.set(0, 4.35, 11.4);
  camera.lookAt(0, 0.05, 0);

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: "low-power", stencil: false });
  } catch (error) {
    stage.classList.add("world-static");
    console.warn("Miniature world fell back to its painted scene.", error);
  }

  if (renderer) {
    stage.classList.add("world-rendered");
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.25));

    const colors = {
      grass: "#aab99b", hill: "#91a88c", hillLight: "#b9c5a7", road: "#e7d9bd",
      plaster: "#eadfca", cream: "#fff3dc", terracotta: "#c77e68", rust: "#b96958",
      slate: "#778493", sky: "#b7d4da", trunk: "#8a6e58", leaf: "#819b79", leafLight: "#a9b995"
    };
    const vertexShader = `
      varying vec3 vNormal; varying vec3 vPosition; varying vec2 vUv;
      void main() {
        vUv = uv;
        vNormal = normalize(normalMatrix * normal);
        vec4 viewPosition = modelViewMatrix * vec4(position, 1.0);
        vPosition = viewPosition.xyz;
        gl_Position = projectionMatrix * viewPosition;
      }
    `;
    const fragmentShader = `
      uniform vec3 uBaseColor; uniform vec3 uLightDirection; uniform float uGrain;
      varying vec3 vNormal; varying vec3 vPosition; varying vec2 vUv;
      float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
      float noise(vec2 p) {
        vec2 i = floor(p), f = fract(p); f *= f * (3.0 - 2.0 * f);
        float a = hash21(i), b = hash21(i + vec2(1.0,0.0));
        float c = hash21(i + vec2(0.0,1.0)), d = hash21(i + vec2(1.0,1.0));
        return mix(mix(a,b,f.x), mix(c,d,f.x), f.y);
      }
      void main() {
        float tooth = noise(vPosition.xy * 17.0 + vUv * 5.0) - 0.5;
        float light = dot(normalize(vNormal), normalize(uLightDirection));
        float ramp = smoothstep(-0.10, 0.16, light + tooth * 0.07);
        vec3 warm = vec3(1.02, 0.99, 0.94), cool = vec3(0.78, 0.82, 0.89);
        vec3 shaded = uBaseColor * mix(cool, warm, ramp) + tooth * uGrain;
        float luma = dot(shaded, vec3(0.2126,0.7152,0.0722));
        gl_FragColor = vec4(mix(vec3(luma), shaded, 0.82), 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `;
    const materialCache = new Map();
    const material = (color, grain = 0.04) => {
      const key = `${color}:${grain}`;
      if (!materialCache.has(key)) materialCache.set(key, new THREE.ShaderMaterial({
        uniforms: {
          uBaseColor: { value: new THREE.Color(color) },
          uLightDirection: { value: new THREE.Vector3(-0.45, 0.82, 0.55).normalize() },
          uGrain: { value: grain }
        }, vertexShader, fragmentShader
      }));
      return materialCache.get(key);
    };

    const world = new THREE.Group();
    world.rotation.x = -0.12;
    scene.add(world);
    const planet = new THREE.Mesh(new THREE.SphereGeometry(3.15, 48, 34), material(colors.grass, 0.055));
    planet.position.y = -0.05;
    world.add(planet);

    const pointOnPlanet = (lon, lat, radius = 3.2) => new THREE.Vector3(
      radius * Math.cos(lat) * Math.sin(lon),
      radius * Math.sin(lat) - 0.05,
      radius * Math.cos(lat) * Math.cos(lon)
    );
    const place = (group, lon, lat, radius = 3.2) => {
      const normal = pointOnPlanet(lon, lat, 1).normalize();
      group.position.copy(pointOnPlanet(lon, lat, radius));
      group.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);
      world.add(group);
      return group;
    };
    const block = (parent, size, position, color) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material(color));
      mesh.position.set(...position);
      parent.add(mesh);
      return mesh;
    };

    const roadPoints = [];
    for (let index = 0; index <= 56; index++) {
      const lon = -1.18 + (2.36 * index) / 56;
      const lat = 0.06 + Math.sin(lon * 1.7) * 0.12;
      roadPoints.push(pointOnPlanet(lon, lat, 3.205));
    }
    const road = new THREE.Mesh(
      new THREE.TubeGeometry(new THREE.CatmullRomCurve3(roadPoints), 64, 0.052, 5, false),
      material(colors.road, 0.02)
    );
    world.add(road);

    const addHouse = (lon, lat, width, height, wall, roof, turn = 0) => {
      const house = place(new THREE.Group(), lon, lat, 3.23);
      house.rotation.y += turn;
      block(house, [width, height, width * 0.92], [0, height * 0.5, 0], wall);
      const cap = new THREE.Mesh(new THREE.ConeGeometry(width * 0.78, height * 0.34, 4), material(roof));
      cap.position.y = height * 1.17;
      cap.rotation.y = Math.PI / 4;
      house.add(cap);
      block(house, [width * 0.18, height * 0.15, 0.025], [-width * 0.23, height * 0.62, width * 0.47], colors.sky);
      block(house, [width * 0.18, height * 0.15, 0.025], [width * 0.23, height * 0.62, width * 0.47], colors.sky);
      block(house, [width * 0.2, height * 0.32, 0.03], [0, height * 0.16, width * 0.48], colors.trunk);
    };
    [
      [-0.92,0.28,0.42,0.65,colors.plaster,colors.terracotta,-0.18],
      [-0.58,0.45,0.48,0.82,colors.sky,colors.rust,0.10],
      [-0.20,0.22,0.40,0.58,colors.cream,colors.slate,-0.10],
      [0.18,0.39,0.52,0.94,colors.plaster,colors.slate,0.14],
      [0.57,0.24,0.43,0.70,colors.cream,colors.terracotta,-0.14],
      [0.92,0.42,0.46,0.78,colors.sky,colors.rust,0.13],
      [-0.98,-0.02,0.35,0.48,colors.cream,colors.slate,0.18],
      [0.83,-0.05,0.35,0.50,colors.plaster,colors.terracotta,-0.16]
    ].forEach(([lon,lat,width,height,wall,roof,turn]) => addHouse(lon,lat,width,height,wall,roof,turn));

    const addTree = (lon, lat, size = 1) => {
      const tree = place(new THREE.Group(), lon, lat, 3.225);
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.035 * size, 0.055 * size, 0.34 * size, 5), material(colors.trunk));
      trunk.position.y = 0.17 * size;
      tree.add(trunk);
      [colors.leaf, colors.leafLight, colors.hill].forEach((tone, index) => {
        const crown = new THREE.Mesh(new THREE.IcosahedronGeometry((0.22 - index * 0.025) * size, 1), material(tone));
        crown.position.set((index - 1) * 0.085 * size, (0.37 + index * 0.1) * size, (index % 2) * 0.04 * size);
        tree.add(crown);
      });
    };
    [
      [-1.25,0.22,0.95],[-1.12,0.55,0.82],[-0.78,0.05,0.88],[-0.42,0.68,0.9],
      [-0.12,0.02,0.75],[0.36,0.7,0.92],[0.69,0.04,0.86],[1.12,0.16,0.9],
      [1.18,0.56,0.75],[-1.42,-0.12,0.76],[1.36,-0.14,0.78]
    ].forEach(([lon,lat,size]) => addTree(lon,lat,size));

    const makeCloud = (x, y, z, scale = 1) => {
      const cloud = new THREE.Group();
      [[0,0,0,0.23],[0.22,0.07,0,0.2],[-0.18,0.04,0.02,0.16]].forEach(([px,py,pz,r]) => {
        const puff = new THREE.Mesh(new THREE.IcosahedronGeometry(r * scale, 1), material(colors.cream, 0.012));
        puff.position.set(px * scale, py * scale, pz * scale);
        cloud.add(puff);
      });
      cloud.position.set(x,y,z);
      scene.add(cloud);
      return cloud;
    };
    const clouds = [makeCloud(-3.45,2,-0.7,1.05), makeCloud(3.4,1.05,-0.5,0.8)];

    const sun = new THREE.Mesh(new THREE.SphereGeometry(0.42,16,12), new THREE.MeshBasicMaterial({ color: colors.terracotta }));
    sun.position.set(3.5,3.05,-1.5);
    scene.add(sun);
    const halo = new THREE.Mesh(new THREE.TorusGeometry(0.58,0.009,3,48), new THREE.MeshBasicMaterial({ color: colors.terracotta, transparent: true, opacity: 0.45 }));
    halo.position.copy(sun.position);
    halo.rotation.x = 0.7;
    scene.add(halo);

    const resize = () => {
      const width = Math.max(1, stage.clientWidth);
      const height = Math.max(1, stage.clientHeight);
      camera.aspect = width / height;
      camera.position.z = width < 620 ? 13.3 : 11.4;
      camera.position.y = width < 620 ? 4.8 : 4.35;
      camera.updateProjectionMatrix();
      renderer.setPixelRatio(Math.min(devicePixelRatio || 1, width < 620 ? 1.1 : 1.25));
      renderer.setSize(width, height, false);
      renderer.render(scene, camera);
    };
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(stage);

    let active = true;
    let visible = document.visibilityState === "visible";
    let dragging = false;
    let targetX = 0;
    let targetY = 0;
    let lastX = 0;
    let lastY = 0;
    let lastTime = performance.now();
    let animationFrame = 0;
    const normalizedPointer = (event) => {
      const rect = stage.getBoundingClientRect();
      return { x: (event.clientX - rect.left) / rect.width - 0.5, y: (event.clientY - rect.top) / rect.height - 0.5 };
    };
    stage.addEventListener("pointerdown", (event) => {
      if (event.pointerType === "mouse" && event.button !== 0) return;
      dragging = true;
      lastX = event.clientX;
      lastY = event.clientY;
      stage.setPointerCapture(event.pointerId);
    });
    stage.addEventListener("pointermove", (event) => {
      if (dragging) {
        targetY += (event.clientX - lastX) * 0.004;
        targetX += (event.clientY - lastY) * 0.002;
        lastX = event.clientX;
        lastY = event.clientY;
      } else if (event.pointerType === "mouse") {
        const point = normalizedPointer(event);
        targetY = point.x * 0.16;
        targetX = point.y * 0.055;
      }
    }, { passive: true });
    const stopDrag = () => { dragging = false; };
    stage.addEventListener("pointerup", stopDrag);
    stage.addEventListener("pointercancel", stopDrag);
    stage.addEventListener("pointerleave", () => { if (!dragging) { targetX = 0; targetY = 0; } });
    document.addEventListener("visibilitychange", () => { visible = document.visibilityState === "visible"; lastTime = performance.now(); });
    const stageObserver = new IntersectionObserver((entries) => {
      active = entries[0].isIntersecting;
      lastTime = performance.now();
    });
    stageObserver.observe(stage);

    const animate = (now) => {
      animationFrame = requestAnimationFrame(animate);
      if (!active || !visible) return;
      const delta = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;
      if (!reducedMotion && !dragging) world.rotation.y += delta * 0.055;
      world.rotation.y += (targetY - world.rotation.y) * Math.min(1, delta * 1.8);
      world.rotation.x += (-0.12 + targetX - world.rotation.x) * Math.min(1, delta * 1.4);
      clouds[0].position.y = 2 + Math.sin(now * 0.00035) * 0.025;
      clouds[1].position.y = 1.05 + Math.cos(now * 0.00028) * 0.018;
      if (!reducedMotion) halo.rotation.z += delta * 0.035;
      renderer.render(scene, camera);
    };
    animationFrame = requestAnimationFrame(animate);

    window.addEventListener("pagehide", () => {
      cancelAnimationFrame(animationFrame);
      resizeObserver.disconnect();
      stageObserver.disconnect();
      renderer.dispose();
      materialCache.forEach((entry) => entry.dispose());
    }, { once: true });
  }
}
